import { Member } from './member';

export interface Team {
    idTeam: number;
    members: Member[];
    name: string;
}
  