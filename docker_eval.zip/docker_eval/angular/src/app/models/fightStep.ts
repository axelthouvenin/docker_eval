export interface FightStep {
    step: number;
    fighter1Damages: number;
    fighter2Damages: number;
}
