export const environment = {
  production: true,
  backendUrl: '{{ BACKEND_URL }}'
};
