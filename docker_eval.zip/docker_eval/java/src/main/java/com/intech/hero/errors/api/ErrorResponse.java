package com.intech.hero.errors.api;

import lombok.Data;

@Data
public class ErrorResponse {

    private String message;

}
